# Frozen known-answer qualification

Preparation performs tokenization only; it sends no model request. Execution is a separate, explicitly controlled step.

The eight cases are fixed before outputs: four exact-copy and four early-context retrieval cases, with two cases at each of 512 and 8192 input tokens per family. Every case has an eight-word answer chosen by the recorded seeded rule. All 32 requests must pass integrity checks, and each case must produce identical text across all four routes after outer-whitespace stripping only. Gold-answer accuracy is reported separately and does not determine acceptance. Returned token IDs are diagnostic because leading whitespace is intentionally normalized. No case may be filtered, replaced or rerun selectively.

The original five-token equality failure remains evidence and remains unchanged. This suite is an additional aggregate known-answer diagnosis. Keep deployed images, TRITON_ATTN, compilation/CUDA graphs and non-eager execution unchanged. Route, worker identity and NIXL counter qualification remain separate mandatory checks.
