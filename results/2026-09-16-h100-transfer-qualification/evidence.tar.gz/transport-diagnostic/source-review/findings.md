# Local CUDA IPC qualification follow-up

Read-only source review after the live diagnostic; no further GPU or cloud operations.

## Established evidence

The standalone 256-KiB CUDA READ in the existing prefill/local-decode pods selected software emulation through tcp/eth0 for all message sizes in the emitted protocol table. Every payload byte was verified and both diagnostic processes exited zero. This does not directly trace the vLLM allocation's transfer path.

Runtime versions observed: NIXL 1.3.1 and UCX 1.21.0. Source references below use their matching release tags; the wheel's complete build provenance was not recovered.

## Source-grounded conclusions

- A single visible GPU is not, by itself, a UCX CUDA IPC exclusion. UCX deliberately checks hidden-peer reachability by opening the remote memory handle, rather than relying on device enumeration: [cuda_ipc_md.c lines 369–391](https://github.com/openucx/ucx/blob/v1.21.0/src/uct/cuda/cuda_ipc/cuda_ipc_md.c#L369).
- `UCX_CUDA_IPC_ENABLE_GET_ZCOPY=on` is valid. The parser accepts the on/off type, and the explicit ON setting bypasses the heuristic that disables GET when no NVLinks are detected: [cuda_ipc_iface.c lines 235–247](https://github.com/openucx/ucx/blob/v1.21.0/src/uct/cuda/cuda_ipc/cuda_ipc_iface.c#L235). This flag grants eligibility; it cannot repair an inaccessible remote handle.
- CUDA IPC requires matching system IDs unless multi-node NVLink is supported: [cuda_ipc_iface.c lines 125–151](https://github.com/openucx/ucx/blob/v1.21.0/src/uct/cuda/cuda_ipc/cuda_ipc_iface.c#L125). The system ID comes from kernel boot ID, with a machine-guid fallback: [uid.c](https://github.com/openucx/ucx/blob/v1.21.0/src/ucs/sys/uid.c#L18). Different pod hostnames alone are not evidence of failed locality detection.
- UCX can register a CUDA allocation while labeling its IPC handle `NO_IPC`, for example when an allocation is not legacy-IPC capable and lacks the supported fabric handle type: [cuda_ipc_md.c lines 180–264](https://github.com/openucx/ucx/blob/v1.21.0/src/uct/cuda/cuda_ipc/cuda_ipc_md.c#L180). A successful NIXL VRAM registration therefore does not prove IPC eligibility.
- During key unpack, UCX tests whether it can map the remote allocation. Failure makes the key unreachable and is reported at DEBUG level: [cuda_ipc_md.c lines 369–397](https://github.com/openucx/ucx/blob/v1.21.0/src/uct/cuda/cuda_ipc/cuda_ipc_md.c#L369), [cuda_ipc_cache.c](https://github.com/openucx/ucx/blob/v1.21.0/src/uct/cuda/cuda_ipc/cuda_ipc_cache.c#L282). INFO-level success logs cannot exclude such a failure.

## Bounded next step for review

At a separately approved future run, repeat only the existing tiny diagnostic with `UCX_LOG_LEVEL=debug` on those new diagnostic processes, preserving devices, privileges, allocation size, and transport configuration. Inspect IPC lane reachability and export/open errors before changing any deployment setting. Compare boot IDs only if locality is rejected; inspect allocation handle capabilities if UCX reports NO_IPC; investigate the exact CUDA error if handle mapping fails. If CUDA IPC is reachable but TCP still wins, inspect the transport selection explanation before changing performance heuristics.

The all-sizes TCP table makes missing or unusable IPC eligibility a useful first hypothesis; it does not establish which check failed. No blanket privilege or GPU-visibility expansion is justified by current evidence. After a diagnostic qualifies IPC, actual vLLM payload qualification remains required before performance claims or benchmarking.
