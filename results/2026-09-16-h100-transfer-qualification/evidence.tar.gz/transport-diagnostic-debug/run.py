import json,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parent
kube=['kubectl','--kubeconfig',str(root.parent/'kubeconfig'),'-n','topology-measurement','exec']
producer='prefill-65f67b5759-rt7fw'
consumer='decode-local-7bf684b865-qmh7p'
stem='/tmp/topology-nixl-diagnostic-debug-20260916T0600'
script=(root/'diagnostic.py').read_text()
def cmd(pod,args,stdin=False):return kube+(['-i'] if stdin else [])+[pod,'-c','modelserver','--']+args
def execute(pod,args,input=None):return subprocess.run(cmd(pod,args,input is not None),input=input,text=True,capture_output=True,timeout=20)
log=(root/'producer.log').open('w')
proc=subprocess.Popen(cmd(producer,['timeout','115','env','UCX_LOG_LEVEL=debug','python3','-u','-','producer',stem],True),stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True)
proc.stdin.write(script);proc.stdin.close()
result={'producer_pod':producer,'consumer_pod':consumer,'remote_stem':stem,'allocation_bytes_per_process':262144}
try:
 deadline=time.monotonic()+45
 while True:
  md=execute(producer,['cat',stem+'.metadata.json'])
  if md.returncode==0:break
  if proc.poll() is not None or time.monotonic()>deadline:raise RuntimeError('producer did not publish metadata')
  time.sleep(1)
 (root/'producer-metadata.json').write_text(md.stdout)
 put=execute(consumer,['python3','-c','import pathlib,sys;pathlib.Path(sys.argv[1]).write_text(sys.stdin.read())',stem+'.metadata.json'],md.stdout)
 if put.returncode:raise RuntimeError(put.stderr)
 con=subprocess.run(cmd(consumer,['timeout','115','env','UCX_LOG_LEVEL=debug','python3','-u','-','consumer',stem],True),input=script,text=True,capture_output=True,timeout=120)
 (root/'consumer.log').write_text(con.stdout+'\n'+con.stderr)
 result['consumer_exit']=con.returncode
finally:
 done=execute(producer,['python3','-c','import pathlib,sys;pathlib.Path(sys.argv[1]).touch()',stem+'.done'])
 result['producer_stop_signal_exit']=done.returncode
 try:result['producer_exit']=proc.wait(timeout=25)
 except subprocess.TimeoutExpired:result['producer_exit']='still-running-until-115s-timeout'
 log.close()
 (root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
