# Final bounded local transport diagnostic

Both diagnostic processes exited 0. No engine settings, model cache buffers, inference requests, pods, or privileges were changed. The only new setting was `UCX_LOG_LEVEL=debug` for the short-lived diagnostic processes. Each requested its own 262,144-byte CUDA tensor; PyTorch backed the producer tensor with a 2,097,152-byte allocator block, as reported in UCX's handle metadata.

The consumer log supplies the missing rejection:

- Line 1081: UCX identifies the peer configuration as intra-node and includes `cuda_ipc/cuda`.
- Line 1439: UCX creates the CUDA IPC lane.
- Line 1447: `cuIpcOpenMemHandle() failed: invalid argument`.
- Line 1448: `failed to open ipc mem handle` for producer PID 51157, allocation base `0x7c44efe00000`, backing length 2097152.
- Lines 1468–1470: actual CUDA-to-CUDA READ selects software emulation over `tcp/eth0` for all sizes.
- Line 1486: 262,144 bytes transferred, every byte verified equal to 73, checksum 19,136,512; result DONE.

This establishes the immediate reason for the diagnostic fallback: CUDA rejected the remote IPC handle when UCX tried to open it. It was not missing intra-node detection, a missing CUDA IPC transport, or an absent GET-enable setting. The underlying reason CUDA returned invalid argument remains unresolved; this result alone does not justify broadening device access or container privileges.

An earlier `cuMemCreate ... operation not permitted` message occurs during setup in both processes. It is not the same API or error as the decisive remote handle-open failure. Do not present it as the established cause.

The diagnostic establishes the same deployment's standalone transfer path, not a direct trace of vLLM's cache allocation. Future work should first isolate the exact CUDA IPC export/open contract using fresh allocations, keeping environmental variables and privileges controlled, before starting another model-serving benchmark. No further experiments were run after this pair.
