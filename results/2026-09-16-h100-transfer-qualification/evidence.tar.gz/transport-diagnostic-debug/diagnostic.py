import base64, ctypes, json, os, pathlib, sys, time
import torch
from nixl._api import nixl_agent, nixl_agent_config

role, stem = sys.argv[1:3]
size = 262144
torch.cuda.set_device(0)
buf = torch.empty(size, dtype=torch.uint8, device='cuda')
buf.fill_(73 if role == 'producer' else 0)
torch.cuda.synchronize()
agent = nixl_agent('topology-diagnostic-' + role + '-' + pathlib.Path(stem).name,
                   nixl_agent_config(backends=['UCX']))
reg = agent.register_memory(buf, backends=['UCX'])
print('DIAGNOSTIC_INIT', json.dumps({'role':role,'pid':os.getpid(),'bytes':size,'device':str(buf.device)}), flush=True)
try:
    if role == 'producer':
        md = {'metadata':base64.b64encode(agent.get_agent_metadata()).decode(), 'address':buf.data_ptr(), 'bytes':size, 'device':0}
        pathlib.Path(stem+'.metadata.tmp').write_text(json.dumps(md))
        os.replace(stem+'.metadata.tmp',stem+'.metadata.json')
        deadline=time.monotonic()+90
        while not pathlib.Path(stem+'.done').exists():
            if time.monotonic()>deadline: raise TimeoutError('producer waiting for completion')
            time.sleep(.1)
        print('DIAGNOSTIC_PRODUCER_DONE',flush=True)
    else:
        md=json.loads(pathlib.Path(stem+'.metadata.json').read_text())
        remote=agent.add_remote_agent(base64.b64decode(md['metadata']))
        local_desc=agent.get_xfer_descs(buf)
        remote_desc=agent.get_xfer_descs([(md['address'],md['bytes'],md['device'])], 'VRAM')
        handle=agent.initialize_xfer('READ',local_desc,remote_desc,remote,backends=['UCX'])
        start=time.monotonic()
        state=agent.transfer(handle)
        while state=='PROC' and time.monotonic()-start<20:
            time.sleep(.001)
            state=agent.check_xfer_state(handle)
        if state!='DONE': raise RuntimeError('transfer state '+state)
        torch.cuda.synchronize()
        valid=bool(torch.all(buf==73).item())
        result={'state':state,'bytes':size,'all_bytes_equal_73':valid,'checksum':int(buf.sum().item()),'elapsed_seconds':time.monotonic()-start}
        print('DIAGNOSTIC_RESULT',json.dumps(result),flush=True)
        agent.release_xfer_handle(handle)
        if not valid: raise RuntimeError('payload mismatch')
finally:
    agent.deregister_memory(reg)
    ctypes.CDLL(None).fflush(None)
