import argparse,json,pathlib
p=argparse.ArgumentParser();p.add_argument('--node',required=True);p.add_argument('--count',type=int,default=2);a=p.parse_args()
name='hardware-local';ns='topology-measurement';src=pathlib.Path('/Users/rayhanmemon/disagg-boundary/infra/topology/gpu-inspect.py').read_text()
cm={'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':name,'namespace':ns},'data':{'gpu-inspect.py':src}}
image='docker.io/vllm/vllm-openai:v0.26.0@sha256:770fe65b2c73ee74a5c42165cf3433de4048cc2cd9c57a937ca4e35aba5aa87b'
pod={'apiVersion':'v1','kind':'Pod','metadata':{'name':name,'namespace':ns},'spec':{'nodeSelector':{'kubernetes.io/hostname':a.node},'restartPolicy':'Never','activeDeadlineSeconds':900,'automountServiceAccountToken':False,'containers':[{'name':'inspect','image':image,'command':['python3','/probe/gpu-inspect.py','--expected-count',str(a.count)],'resources':{'requests':{'cpu':'1','memory':'2Gi','nvidia.com/gpu':str(a.count)},'limits':{'cpu':'2','memory':'4Gi','nvidia.com/gpu':str(a.count)}},'volumeMounts':[{'name':'probe','mountPath':'/probe','readOnly':True}]}],'volumes':[{'name':'probe','configMap':{'name':name}}]}}
print(json.dumps({'apiVersion':'v1','kind':'List','items':[cm,pod]},indent=2))
